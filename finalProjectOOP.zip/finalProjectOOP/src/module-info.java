module finalProjectOOP {
	requires java.desktop;
}