package finalProjectOOP;

import java.util.Vector;

public class Organization {
	String name;
	String head;
	private static Vector<Student> members = new Vector<Student>();
	
}
