package finalProjectOOP;

public enum TeacherDegree {

}
