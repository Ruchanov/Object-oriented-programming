package finalProjectOOP;

public enum Status {
	Married,
	NotMarried
}
