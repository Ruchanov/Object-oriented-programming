package finalProjectOOP;

import java.util.Vector;

public class test2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vector<String> v = new Vector<String>();
		v.add("kmoaxma,sp,a");
		v.add("ksalxasxlkm");
		System.out.print(v);
	}

}
