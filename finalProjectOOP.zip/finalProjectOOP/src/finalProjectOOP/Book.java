package finalProjectOOP;

public class Book {
	String name;
	String author;
	Book(String n, String a){
		this.name = n;
		this.author = a;
	}
}
