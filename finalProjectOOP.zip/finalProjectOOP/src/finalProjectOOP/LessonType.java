package finalProjectOOP;

public enum LessonType {
	Lecture,
	Practice,
	Laboratory
}
