package finalProjectOOP;

public enum UserType {
	Student,
	Teacher,
	Manager,
	Librarian,
	Admin
}
