package finalProjectOOP;

public enum Gender {
	Female,
	Male
}
