package finalProjectOOP;

public enum CourseType {
	Elective,
	Major,
	DasicSubject
}
