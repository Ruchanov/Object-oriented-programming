package finalProjectOOP;

public enum Degree {
	Bachelor,
	Master,
	PHD
}
