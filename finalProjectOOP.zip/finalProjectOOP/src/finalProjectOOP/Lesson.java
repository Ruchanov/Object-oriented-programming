package finalProjectOOP;

import java.util.Date;

public class Lesson {
	LessonType type;
	Date time;
	
}
