package finalProjectOOP;

public enum Faculty {
	ISE,
	FIT,
	NGD,
	MCM
}
